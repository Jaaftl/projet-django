from django.urls import path

from . import views, genre_views

urlpatterns = [
    path('', views.index),
    path('ajout/', views.ajout),
    path('traitement/', views.traitement),
    path('affiche/<int:id>/', views.affiche),
    path('maj/<int:id>/', views.maj),
    path('traitementmaj/<int:id>/', views.traitementmaj),
    path('delete/<int:id>/', views.delete),
    #pour les genres
    path('indexgenre/', genre_views.index),
    path('ajoutgenre/', genre_views.ajout),
    path('traitementgenre/', genre_views.traitement),
    path('affichegenre/<int:id>/', genre_views.affiche),
    path('traitementupdategenre/<int:id>/', genre_views.traitementupdate),
    path('deletegenre/<int:id>/', genre_views.delete),
]
