from django.shortcuts import render, HttpResponseRedirect
from .forms import MusiqueForm
from . import models

def index(request):
    liste = list(models.Musique.objects.all())
    return render(request, 'myfirstapp/index.html',{"liste" : liste})


def ajout(request):
    if request.method == "POST":
        form = MusiqueForm(request)
        if form.is_valid(): # validation du formulaire.
            musique = form.save() # sauvegarde dans la base
            return render(request,"myfirstapp/affiche.html", {"form": form}) #aa
        else:
            return render(request,"myfirstapp/ajout.html",{"form": form})
    else:
        form = MusiqueForm() # création d'un formulaire vide
        return render(request,"myfirstapp/ajout.html",{"form" : form})

def traitement(request):
    mform = MusiqueForm(request.POST)
    if mform.is_valid():
        musique = mform.save()
        return HttpResponseRedirect("/myfirstapp/")
    else:
        return render(request,"myfirstapp/ajout.html",{"form" : mform})

def affiche(request, id):
    musique = models.Musique.objects.get(pk=id)
    return render(request,"myfirstapp/affiche.html",{"musique" : musique}) #aa

def maj(request, id):
    musique = models.Musique.objects.get(pk=id)
    form = MusiqueForm(musique.detail())
    return render(request, "myfirstapp/ajout.html", {"form" : form, "id": id })

def traitementmaj(request, id):
    mform = MusiqueForm(request.POST)
    if mform.is_valid():
        musique = mform.save(commit=False) # création d'un objet "musique"" avec les données du formulaire mais sans l'enregistrer dans la base.
        musique.id = id # modification
        musique.save() # mise à jour
        return HttpResponseRedirect("/myfirstapp/")
    else:
        return render(request, "myfirstapp/ajout.html", {"form": mform, "id": id})

def delete(request, id):
    musique = models.Musique.objects.get(pk=id)
    musique.delete()
    return HttpResponseRedirect("/myfirstapp/")



