from django.db import models

class Musique(models.Model): #déclare la classe Musique
    titre = models.CharField(max_length=100) # défini un champs de type texte de 100 caractères maximum

    auteur = models.CharField(max_length = 100)

    date_parution = models.DateField(blank=True, null = True) # champs de type date,pouvant être null ou ne pas être rempli

    album = models.CharField(max_length=100) # champs de type texte

    genre = models.ForeignKey("genre", on_delete=models.CASCADE, default=None)

    def __str__(self):
        chaine = f"{self.titre} composée par {self.auteur} apparue le {self.date_parution}, dans l'album {self.album}"
        return chaine

    def detail(self):
        return {"titre":self.titre, "auteur":self.auteur, "date_parution":self.date_parution, "album":self.album, "genre":self.genre}


class Genre(models.Model):
    nom = models.CharField(max_length=100, blank=False)
    description = models.CharField(max_length=500)
    def __str__(self):
        chaine = f"{self.nom}"
        return chaine
