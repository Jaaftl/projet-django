from django.shortcuts import render
from .forms import GenreForm
from . import models
from django.http import HttpResponseRedirect

def index(request):
    liste = list(models.Genre.objects.all())
    return render(request, 'genre/indexgenre.html', {"liste": liste})

def ajout(request):
    if request.method == "POST":
        form = GenreForm(request)
        if form.is_valid(): # validation du formulaire.
            genre = form.save() # sauvegarde dans la base
            return render(request,"myfirstapp/index.html", {"form": form}) #aa
        else:
            return render(request,"genre/ajout.html",{"form": form})
    else:
        form = GenreForm() # création d'un formulaire vide
        return render(request,"genre/ajout.html",{"form" : form})

def traitement(request):
    gform = GenreForm(request.POST)
    if gform.is_valid():
        genre = gform.save()
        return HttpResponseRedirect("/myfirstapp/")
    else:
        return render(request,"genre/ajout.html",{"form" : genre})

def affiche(request, id):
    genre = models.Genre.objects.get(pk=id)
    return render(request,"genre/affichegenre.html",{"genre" : genre}) #aa

def traitementupdate(request, id):
    gform = GenreForm(request.POST)
    if gform.is_valid():
        genre = mform.save(commit=False) # création d'un objet "genre" avec les données du formulaire mais sans l'enregistrer dans la base.
        genre.id = id; # modification
        genre.save() # mise à jour
        return HttpResponseRedirect("/myfirstapp/")
    else:
        return render(request, "myfirstapp/traitementupdate.html", {"form": mform, "id": id})

def delete(request, id):
    genre = models.Genre.objects.get(pk=id)
    genre.delete()
    return HttpResponseRedirect("/myfirstapp/indexgenre/")
