from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models

class MusiqueForm(ModelForm):
    class Meta:
        model = models.Musique
        fields = ('titre', 'auteur', 'date_parution', 'album','genre')
        labels = {
            'titre' : _('Titre de la musique'),
            'auteur' : _('Auteur/groupe de musique') ,
            'date_parution' : _('date de parution'),
            'album' : _('Album'),
            'genre' : _('Genre')
}

class GenreForm(ModelForm):
    class Meta:
        model = models.Genre
        fields = ('nom', 'description')
        labels = {
            'nom' : _('Nom du genre'),
            'descriptin' : _('Description du genre')
        }